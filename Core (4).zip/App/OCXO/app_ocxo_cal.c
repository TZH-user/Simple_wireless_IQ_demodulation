#include "app_ocxo_cal.h"

#include "app_board_flash.h"
#include "dac.h"
#include "RtosTypes.h"

#include <stddef.h>
#include <stdio.h>
#include <string.h>

#define APP_OCXO_CAL_DAC_MAX_CODE 4095U
#define APP_OCXO_CAL_DAC_VREF_MV 3300U
#define APP_OCXO_CAL_FLASH_ADDR (APP_BOARD_FLASH_TOTAL_SIZE - (2UL * APP_BOARD_FLASH_SECTOR_SIZE))
#define APP_OCXO_CAL_FLASH_MAGIC 0x4F43584FUL
#define APP_OCXO_CAL_FLASH_VERSION 4UL
#define APP_OCXO_CAL_FLASH_CRC_SEED 2166136261UL

typedef struct
{
    uint32_t magic;
    uint32_t version;
    uint32_t record_size;
    uint32_t dac_mv;
    uint32_t crc;
} app_ocxo_cal_flash_record_v1_t;

typedef struct
{
    uint32_t magic;
    uint32_t version;
    uint32_t record_size;
    uint32_t dac_mv;
    uint32_t auto_task_enable;
    uint32_t reserved0;
    uint32_t reserved1;
    uint32_t crc;
} app_ocxo_cal_flash_record_v2_t;

typedef struct
{
    uint32_t magic;
    uint32_t version;
    uint32_t record_size;
    uint32_t dac_mv;
    uint32_t auto_task_enable;
    uint32_t boot_anim_enable;
    uint32_t reserved0;
    uint32_t crc;
} app_ocxo_cal_flash_record_v3_t;

typedef struct
{
    uint32_t magic;
    uint32_t version;
    uint32_t record_size;
    uint32_t dac_mv;
    uint32_t auto_task_enable;
    uint32_t boot_anim_enable;
    uint32_t runtime_monitor_enable;
    uint32_t crc;
} app_ocxo_cal_flash_record_v4_t;

static app_ocxo_cal_status_t g_ocxo_status =
{
    .dac_mv = APP_OCXO_CAL_DEFAULT_MV,
    .step_mv = APP_OCXO_CAL_STEP_MID_MV,
    .state = APP_OCXO_CAL_NONE,
    .valid = 0U,
    .flash_loaded = 0U,
    .auto_task_enable = APP_OCXO_CAL_AUTO_TASK_DEFAULT_ENABLE,
    .boot_anim_enable = APP_OCXO_CAL_BOOT_ANIM_DEFAULT_ENABLE,
    .runtime_monitor_enable = APP_OCXO_CAL_RUNTIME_MONITOR_DEFAULT_ENABLE
};
static uint32_t g_ocxo_saved_mv = APP_OCXO_CAL_DEFAULT_MV;
static app_ocxo_cal_flash_record_v4_t g_ocxo_flash_record;
static uint8_t g_ocxo_initialized = 0U;

static uint32_t app_ocxo_cal_limit_mv(uint32_t mv);
static uint32_t app_ocxo_cal_mv_to_code(uint32_t mv);
static void app_ocxo_cal_apply_dac(uint32_t mv);
static uint32_t app_ocxo_cal_crc_bytes(const void *record, uint32_t crc_offset);
static uint8_t app_ocxo_cal_decode_record(const app_ocxo_cal_flash_record_v4_t *record,
                                          uint32_t *dac_mv,
                                          uint8_t *auto_task_enable,
                                          uint8_t *boot_anim_enable,
                                          uint8_t *runtime_monitor_enable);
static uint8_t app_ocxo_cal_write_flash(uint8_t update_ocxo_state);
static void app_ocxo_cal_log(const char *text, uint32_t value);

/* 把用户输入电压限制在安全调节范围内。 */
static uint32_t app_ocxo_cal_limit_mv(uint32_t mv)
{
    if (mv < APP_OCXO_CAL_MIN_MV)
    {
        return APP_OCXO_CAL_MIN_MV;
    }

    if (mv > APP_OCXO_CAL_MAX_MV)
    {
        return APP_OCXO_CAL_MAX_MV;
    }

    return mv;
}

/* 将 mV 转成 12 位 DAC 码值。 */
static uint32_t app_ocxo_cal_mv_to_code(uint32_t mv)
{
    if (mv >= APP_OCXO_CAL_DAC_VREF_MV)
    {
        return APP_OCXO_CAL_DAC_MAX_CODE;
    }

    return (mv * APP_OCXO_CAL_DAC_MAX_CODE + (APP_OCXO_CAL_DAC_VREF_MV / 2U)) / APP_OCXO_CAL_DAC_VREF_MV;
}

/* 把当前 OCXO 控制电压输出到 PA4/DAC1_OUT1。 */
static void app_ocxo_cal_apply_dac(uint32_t mv)
{
    uint32_t dac_code = app_ocxo_cal_mv_to_code(mv);

    (void)HAL_DAC_Start(&hdac1, DAC_CHANNEL_1);
    (void)HAL_DAC_SetValue(&hdac1, DAC_CHANNEL_1, DAC_ALIGN_12B_R, dac_code);
}

/* 计算 Flash 记录 CRC，只覆盖 crc 字段之前的数据，便于兼容旧记录。 */
static uint32_t app_ocxo_cal_crc_bytes(const void *record, uint32_t crc_offset)
{
    const uint8_t *bytes = (const uint8_t *)record;
    uint32_t crc = APP_OCXO_CAL_FLASH_CRC_SEED;
    uint32_t idx;

    if (record == NULL)
    {
        return 0UL;
    }

    for (idx = 0UL; idx < crc_offset; idx++)
    {
        crc ^= (uint32_t)bytes[idx];
        crc *= 16777619UL;
    }

    return crc;
}

/* 解码 OCXO Flash 记录；V1 只含电压，自动任务开关使用默认值。 */
static uint8_t app_ocxo_cal_decode_record(const app_ocxo_cal_flash_record_v4_t *record,
                                          uint32_t *dac_mv,
                                          uint8_t *auto_task_enable,
                                          uint8_t *boot_anim_enable,
                                          uint8_t *runtime_monitor_enable)
{
    const app_ocxo_cal_flash_record_v1_t *record_v1;
    const app_ocxo_cal_flash_record_v2_t *record_v2;
    const app_ocxo_cal_flash_record_v3_t *record_v3;

    if (record == NULL)
    {
        return 0U;
    }

    if (record->magic != APP_OCXO_CAL_FLASH_MAGIC)
    {
        return 0U;
    }

    record_v1 = (const app_ocxo_cal_flash_record_v1_t *)record;
    if ((record_v1->version == 1UL) &&
        (record_v1->record_size == sizeof(app_ocxo_cal_flash_record_v1_t)) &&
        (record_v1->dac_mv >= APP_OCXO_CAL_MIN_MV) &&
        (record_v1->dac_mv <= APP_OCXO_CAL_MAX_MV) &&
        (record_v1->crc == app_ocxo_cal_crc_bytes(record_v1, offsetof(app_ocxo_cal_flash_record_v1_t, crc))))
    {
        if (dac_mv != NULL)
        {
            *dac_mv = record_v1->dac_mv;
        }

        if (auto_task_enable != NULL)
        {
            *auto_task_enable = APP_OCXO_CAL_AUTO_TASK_DEFAULT_ENABLE;
        }

        if (boot_anim_enable != NULL)
        {
            *boot_anim_enable = APP_OCXO_CAL_BOOT_ANIM_DEFAULT_ENABLE;
        }

        if (runtime_monitor_enable != NULL)
        {
            *runtime_monitor_enable = APP_OCXO_CAL_RUNTIME_MONITOR_DEFAULT_ENABLE;
        }

        return 1U;
    }

    record_v2 = (const app_ocxo_cal_flash_record_v2_t *)record;
    if ((record_v2->version == 2UL) &&
        (record_v2->record_size == sizeof(app_ocxo_cal_flash_record_v2_t)) &&
        (record_v2->dac_mv >= APP_OCXO_CAL_MIN_MV) &&
        (record_v2->dac_mv <= APP_OCXO_CAL_MAX_MV) &&
        (record_v2->crc == app_ocxo_cal_crc_bytes(record_v2, offsetof(app_ocxo_cal_flash_record_v2_t, crc))))
    {
        if (dac_mv != NULL)
        {
            *dac_mv = record_v2->dac_mv;
        }

        if (auto_task_enable != NULL)
        {
            *auto_task_enable = (record_v2->auto_task_enable != 0UL) ? 1U : 0U;
        }

        if (boot_anim_enable != NULL)
        {
            *boot_anim_enable = APP_OCXO_CAL_BOOT_ANIM_DEFAULT_ENABLE;
        }

        if (runtime_monitor_enable != NULL)
        {
            *runtime_monitor_enable = APP_OCXO_CAL_RUNTIME_MONITOR_DEFAULT_ENABLE;
        }

        return 1U;
    }

    record_v3 = (const app_ocxo_cal_flash_record_v3_t *)record;
    if ((record_v3->version == 3UL) &&
        (record_v3->record_size == sizeof(app_ocxo_cal_flash_record_v3_t)) &&
        (record_v3->dac_mv >= APP_OCXO_CAL_MIN_MV) &&
        (record_v3->dac_mv <= APP_OCXO_CAL_MAX_MV) &&
        (record_v3->crc == app_ocxo_cal_crc_bytes(record_v3, offsetof(app_ocxo_cal_flash_record_v3_t, crc))))
    {
        if (dac_mv != NULL)
        {
            *dac_mv = record_v3->dac_mv;
        }

        if (auto_task_enable != NULL)
        {
            *auto_task_enable = (record_v3->auto_task_enable != 0UL) ? 1U : 0U;
        }

        if (boot_anim_enable != NULL)
        {
            *boot_anim_enable = (record_v3->boot_anim_enable != 0UL) ? 1U : 0U;
        }

        if (runtime_monitor_enable != NULL)
        {
            *runtime_monitor_enable = APP_OCXO_CAL_RUNTIME_MONITOR_DEFAULT_ENABLE;
        }

        return 1U;
    }

    if ((record->version != APP_OCXO_CAL_FLASH_VERSION) ||
        (record->record_size != sizeof(app_ocxo_cal_flash_record_v4_t)) ||
        (record->dac_mv < APP_OCXO_CAL_MIN_MV) ||
        (record->dac_mv > APP_OCXO_CAL_MAX_MV) ||
        (record->crc != app_ocxo_cal_crc_bytes(record, offsetof(app_ocxo_cal_flash_record_v4_t, crc))))
    {
        return 0U;
    }

    if (dac_mv != NULL)
    {
        *dac_mv = record->dac_mv;
    }

    if (auto_task_enable != NULL)
    {
        *auto_task_enable = (record->auto_task_enable != 0UL) ? 1U : 0U;
    }

    if (boot_anim_enable != NULL)
    {
        *boot_anim_enable = (record->boot_anim_enable != 0UL) ? 1U : 0U;
    }

    if (runtime_monitor_enable != NULL)
    {
        *runtime_monitor_enable = (record->runtime_monitor_enable != 0UL) ? 1U : 0U;
    }

    return 1U;
}

/* 写入 OCXO 设置记录；自动任务开关和电压共用一个扇区。 */
static uint8_t app_ocxo_cal_write_flash(uint8_t update_ocxo_state)
{
    app_board_flash_result_t result;
    app_ocxo_cal_state_t old_state = g_ocxo_status.state;
    uint32_t record_dac_mv = (update_ocxo_state != 0U) ? g_ocxo_status.dac_mv : g_ocxo_saved_mv;

    record_dac_mv = app_ocxo_cal_limit_mv(record_dac_mv);

    if (update_ocxo_state != 0U)
    {
        g_ocxo_status.state = APP_OCXO_CAL_SAVING;
    }

    memset(&g_ocxo_flash_record, 0, sizeof(g_ocxo_flash_record));
    g_ocxo_flash_record.magic = APP_OCXO_CAL_FLASH_MAGIC;
    g_ocxo_flash_record.version = APP_OCXO_CAL_FLASH_VERSION;
    g_ocxo_flash_record.record_size = sizeof(g_ocxo_flash_record);
    g_ocxo_flash_record.dac_mv = record_dac_mv;
    g_ocxo_flash_record.auto_task_enable = (g_ocxo_status.auto_task_enable != 0U) ? 1UL : 0UL;
    g_ocxo_flash_record.boot_anim_enable = (g_ocxo_status.boot_anim_enable != 0U) ? 1UL : 0UL;
    g_ocxo_flash_record.runtime_monitor_enable = (g_ocxo_status.runtime_monitor_enable != 0U) ? 1UL : 0UL;
    g_ocxo_flash_record.crc = app_ocxo_cal_crc_bytes(&g_ocxo_flash_record,
                                                     offsetof(app_ocxo_cal_flash_record_v4_t, crc));

    result = app_board_flash_erase_4k(APP_OCXO_CAL_FLASH_ADDR);
    if (result != APP_BOARD_FLASH_OK)
    {
        if (update_ocxo_state != 0U)
        {
            g_ocxo_status.state = APP_OCXO_CAL_ERROR;
        }
        else
        {
            g_ocxo_status.state = old_state;
        }
        return 0U;
    }

    result = app_board_flash_write(APP_OCXO_CAL_FLASH_ADDR,
                                   (const uint8_t *)&g_ocxo_flash_record,
                                   sizeof(g_ocxo_flash_record));
    if (result != APP_BOARD_FLASH_OK)
    {
        if (update_ocxo_state != 0U)
        {
            g_ocxo_status.state = APP_OCXO_CAL_ERROR;
        }
        else
        {
            g_ocxo_status.state = old_state;
        }
        return 0U;
    }

    memset(&g_ocxo_flash_record, 0, sizeof(g_ocxo_flash_record));
    result = app_board_flash_read(APP_OCXO_CAL_FLASH_ADDR,
                                  (uint8_t *)&g_ocxo_flash_record,
                                  sizeof(g_ocxo_flash_record));
    if ((result != APP_BOARD_FLASH_OK) ||
        (app_ocxo_cal_decode_record(&g_ocxo_flash_record, NULL, NULL, NULL, NULL) == 0U))
    {
        if (update_ocxo_state != 0U)
        {
            g_ocxo_status.state = APP_OCXO_CAL_ERROR;
        }
        else
        {
            g_ocxo_status.state = old_state;
        }
        return 0U;
    }

    g_ocxo_status.valid = 1U;
    g_ocxo_status.flash_loaded = 0U;
    if (update_ocxo_state != 0U)
    {
        g_ocxo_saved_mv = g_ocxo_status.dac_mv;
    }
    else if (g_ocxo_status.state == APP_OCXO_CAL_NONE)
    {
        g_ocxo_saved_mv = record_dac_mv;
    }

    if (update_ocxo_state != 0U)
    {
        g_ocxo_status.state = APP_OCXO_CAL_SAVE_OK;
        app_ocxo_cal_apply_dac(g_ocxo_status.dac_mv);
    }
    else
    {
        g_ocxo_status.state = old_state;
    }

    return 1U;
}

static void app_ocxo_cal_log(const char *text, uint32_t value)
{
    char log_buf[80];
    int n;

    if (text == NULL)
    {
        return;
    }

    n = snprintf(log_buf, sizeof(log_buf), "ocxo:%s,%lu\r\n", text, (unsigned long)value);
    if ((n > 0) && ((size_t)n < sizeof(log_buf)))
    {
        print_queue_send(log_buf);
    }
}

/* 初始化 OCXO 电压状态，并先输出默认电压。 */
void app_ocxo_cal_init(void)
{
    if (g_ocxo_initialized != 0U)
    {
        return;
    }

    memset(&g_ocxo_flash_record, 0, sizeof(g_ocxo_flash_record));
    g_ocxo_status.dac_mv = APP_OCXO_CAL_DEFAULT_MV;
    g_ocxo_status.step_mv = APP_OCXO_CAL_STEP_MID_MV;
    g_ocxo_status.state = APP_OCXO_CAL_NONE;
    g_ocxo_status.valid = 0U;
    g_ocxo_status.flash_loaded = 0U;
    g_ocxo_status.auto_task_enable = APP_OCXO_CAL_AUTO_TASK_DEFAULT_ENABLE;
    g_ocxo_status.boot_anim_enable = APP_OCXO_CAL_BOOT_ANIM_DEFAULT_ENABLE;
    g_ocxo_status.runtime_monitor_enable = APP_OCXO_CAL_RUNTIME_MONITOR_DEFAULT_ENABLE;
    g_ocxo_saved_mv = APP_OCXO_CAL_DEFAULT_MV;
    g_ocxo_initialized = 1U;
    app_ocxo_cal_apply_dac(g_ocxo_status.dac_mv);
}

/* 从外部 Flash 读取上次保存的恒温晶振控制电压。 */
uint8_t app_ocxo_cal_load_from_flash(void)
{
    app_board_flash_result_t result;
    uint32_t dac_mv;
    uint8_t auto_task_enable;
    uint8_t boot_anim_enable;
    uint8_t runtime_monitor_enable;

    if (g_ocxo_initialized == 0U)
    {
        app_ocxo_cal_init();
    }

    result = app_board_flash_read(APP_OCXO_CAL_FLASH_ADDR,
                                  (uint8_t *)&g_ocxo_flash_record,
                                  sizeof(g_ocxo_flash_record));
    if ((result != APP_BOARD_FLASH_OK) ||
        (app_ocxo_cal_decode_record(&g_ocxo_flash_record,
                                    &dac_mv,
                                    &auto_task_enable,
                                    &boot_anim_enable,
                                    &runtime_monitor_enable) == 0U))
    {
        g_ocxo_status.state = APP_OCXO_CAL_NONE;
        g_ocxo_status.valid = 0U;
        g_ocxo_status.flash_loaded = 0U;
        g_ocxo_status.auto_task_enable = APP_OCXO_CAL_AUTO_TASK_DEFAULT_ENABLE;
        g_ocxo_status.boot_anim_enable = APP_OCXO_CAL_BOOT_ANIM_DEFAULT_ENABLE;
        g_ocxo_status.runtime_monitor_enable = APP_OCXO_CAL_RUNTIME_MONITOR_DEFAULT_ENABLE;
        g_ocxo_saved_mv = APP_OCXO_CAL_DEFAULT_MV;
        app_ocxo_cal_apply_dac(g_ocxo_status.dac_mv);
        return 0U;
    }

    g_ocxo_status.dac_mv = dac_mv;
    g_ocxo_status.auto_task_enable = auto_task_enable;
    g_ocxo_status.boot_anim_enable = boot_anim_enable;
    g_ocxo_status.runtime_monitor_enable = runtime_monitor_enable;
    g_ocxo_status.state = APP_OCXO_CAL_HISTORY;
    g_ocxo_status.valid = 1U;
    g_ocxo_status.flash_loaded = 1U;
    g_ocxo_saved_mv = g_ocxo_status.dac_mv;
    app_ocxo_cal_apply_dac(g_ocxo_status.dac_mv);
    return 1U;
}

/* 将当前恒温晶振控制电压保存到外部 Flash。 */
uint8_t app_ocxo_cal_save_to_flash(void)
{
    if (app_ocxo_cal_write_flash(1U) == 0U)
    {
        app_ocxo_cal_log("flash,save", 0U);
        return 0U;
    }

    app_ocxo_cal_log("flash,save", g_ocxo_status.dac_mv);
    return 1U;
}

/* 进入手动校准状态，保持当前 DAC 电压连续输出。 */
void app_ocxo_cal_enter(void)
{
    g_ocxo_status.state = APP_OCXO_CAL_RUNNING;
    app_ocxo_cal_apply_dac(g_ocxo_status.dac_mv);
}

/* 退出手动校准界面；未保存的新电压仍继续输出，但右上角状态不再显示 RUN。 */
void app_ocxo_cal_leave(void)
{
    if (g_ocxo_status.state != APP_OCXO_CAL_RUNNING)
    {
        return;
    }

    if (g_ocxo_status.valid == 0U)
    {
        g_ocxo_status.state = APP_OCXO_CAL_NONE;
    }
    else if ((g_ocxo_status.flash_loaded != 0U) && (g_ocxo_status.dac_mv == g_ocxo_saved_mv))
    {
        g_ocxo_status.state = APP_OCXO_CAL_HISTORY;
    }
    else
    {
        g_ocxo_status.state = APP_OCXO_CAL_CURRENT;
    }
}

/* 直接设置 PA4/DAC1_OUT1 电压，单位 mV。 */
void app_ocxo_cal_set_mv(uint32_t mv)
{
    g_ocxo_status.dac_mv = app_ocxo_cal_limit_mv(mv);
    g_ocxo_status.valid = 1U;
    if (g_ocxo_status.state != APP_OCXO_CAL_SAVING)
    {
        g_ocxo_status.state = APP_OCXO_CAL_RUNNING;
    }
    app_ocxo_cal_apply_dac(g_ocxo_status.dac_mv);
}

/* 按当前步进增减 PA4/DAC1_OUT1 电压。 */
void app_ocxo_cal_adjust(int32_t delta_mv)
{
    int32_t next_mv = (int32_t)g_ocxo_status.dac_mv + delta_mv;

    if (next_mv < (int32_t)APP_OCXO_CAL_MIN_MV)
    {
        next_mv = (int32_t)APP_OCXO_CAL_MIN_MV;
    }
    else if (next_mv > (int32_t)APP_OCXO_CAL_MAX_MV)
    {
        next_mv = (int32_t)APP_OCXO_CAL_MAX_MV;
    }

    app_ocxo_cal_set_mv((uint32_t)next_mv);
}

/* 循环切换 1mV、10mV、100mV 三档调节步进。 */
void app_ocxo_cal_cycle_step(void)
{
    if (g_ocxo_status.step_mv == APP_OCXO_CAL_STEP_FINE_MV)
    {
        g_ocxo_status.step_mv = APP_OCXO_CAL_STEP_MID_MV;
    }
    else if (g_ocxo_status.step_mv == APP_OCXO_CAL_STEP_MID_MV)
    {
        g_ocxo_status.step_mv = APP_OCXO_CAL_STEP_COARSE_MV;
    }
    else
    {
        g_ocxo_status.step_mv = APP_OCXO_CAL_STEP_FINE_MV;
    }
}

void app_ocxo_cal_get_status(app_ocxo_cal_status_t *status_out)
{
    if (status_out == NULL)
    {
        return;
    }

    *status_out = g_ocxo_status;
}

uint8_t app_ocxo_cal_get_auto_task_enable(void)
{
    return (g_ocxo_status.auto_task_enable != 0U) ? 1U : 0U;
}

/* UI 修改自动运行开关后立即落盘，保存时会保留当前 OCXO 电压。 */
uint8_t app_ocxo_cal_set_auto_task_enable(uint8_t enable)
{
    g_ocxo_status.auto_task_enable = (enable != 0U) ? 1U : 0U;
    if (app_ocxo_cal_write_flash(0U) == 0U)
    {
        app_ocxo_cal_log("auto_task,save", 0U);
        return 0U;
    }

    app_ocxo_cal_log("auto_task", g_ocxo_status.auto_task_enable);
    return 1U;
}

uint8_t app_ocxo_cal_get_boot_anim_enable(void)
{
    return (g_ocxo_status.boot_anim_enable != 0U) ? 1U : 0U;
}

/* UI 修改启动动画开关后立即落盘；该开关只影响下一次上电启动流程。 */
uint8_t app_ocxo_cal_set_boot_anim_enable(uint8_t enable)
{
    g_ocxo_status.boot_anim_enable = (enable != 0U) ? 1U : 0U;
    if (app_ocxo_cal_write_flash(0U) == 0U)
    {
        app_ocxo_cal_log("boot_anim,save", 0U);
        return 0U;
    }

    app_ocxo_cal_log("boot_anim", g_ocxo_status.boot_anim_enable);
    return 1U;
}

uint8_t app_ocxo_cal_get_runtime_monitor_enable(void)
{
    return (g_ocxo_status.runtime_monitor_enable != 0U) ? 1U : 0U;
}

/* UI 修改运行中监测开关后立即落盘，并让 DemodTask 在下一块 ADC 数据起使用新设置。 */
uint8_t app_ocxo_cal_set_runtime_monitor_enable(uint8_t enable)
{
    g_ocxo_status.runtime_monitor_enable = (enable != 0U) ? 1U : 0U;
    if (app_ocxo_cal_write_flash(0U) == 0U)
    {
        app_ocxo_cal_log("runtime_monitor,save", 0U);
        return 0U;
    }

    app_ocxo_cal_log("runtime_monitor", g_ocxo_status.runtime_monitor_enable);
    return 1U;
}
