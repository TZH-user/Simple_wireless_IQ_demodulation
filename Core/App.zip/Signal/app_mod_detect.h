﻿#ifndef APP_MOD_DETECT_H
#define APP_MOD_DETECT_H

#include <stdint.h>

#include "AppDebugConfig.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifndef APP_MODDET_MIN_AC_POWER
#define APP_MODDET_MIN_AC_POWER              120U
#endif

#ifndef APP_MODDET_DEFAULT_SAMPLE_RATE_HZ
#define APP_MODDET_DEFAULT_SAMPLE_RATE_HZ    3200000UL
#endif

#ifndef APP_MODDET_MAX_BLOCK_SAMPLES
#define APP_MODDET_MAX_BLOCK_SAMPLES         4096U
#endif

#ifndef APP_MODDET_FFT_LEN
#define APP_MODDET_FFT_LEN                   512U
#endif

#ifndef APP_MODDET_TRIM_COUNT
#define APP_MODDET_TRIM_COUNT                128U
#endif

#ifndef APP_MODDET_AM_ENV_PM_THRESHOLD
#define APP_MODDET_AM_ENV_PM_THRESHOLD       450U
#endif

#ifndef APP_MODDET_FREQ_ACTIVITY_THRESHOLD
#define APP_MODDET_FREQ_ACTIVITY_THRESHOLD   28U
#endif

#ifndef APP_MODDET_PSK_MIN_FREQ_PM
#define APP_MODDET_PSK_MIN_FREQ_PM           50U
#endif

#ifndef APP_MODDET_PSK_MAX_FREQ_PM
#define APP_MODDET_PSK_MAX_FREQ_PM           220U
#endif

#ifndef APP_MODDET_PSK_MIN_EDGE_PM
#define APP_MODDET_PSK_MIN_EDGE_PM           40U
#endif

#ifndef APP_MODDET_PSK_MAX_HIST_PEAKS
#define APP_MODDET_PSK_MAX_HIST_PEAKS        2U
#endif

#ifndef APP_MODDET_FSK_MIN_FREQ_PM
#define APP_MODDET_FSK_MIN_FREQ_PM           40U
#endif

#ifndef APP_MODDET_SIGN_DOMINANT_PERCENT
#define APP_MODDET_SIGN_DOMINANT_PERCENT     75U
#endif

#ifndef APP_MODDET_SIGN_MINOR_PERCENT
#define APP_MODDET_SIGN_MINOR_PERCENT        25U
#endif

#ifndef APP_MODDET_ASK_MAX_ENV_LEVELS
#define APP_MODDET_ASK_MAX_ENV_LEVELS        4U
#endif

#ifndef APP_MODDET_ASK_MIN_EDGE_PM
#define APP_MODDET_ASK_MIN_EDGE_PM           40U
#endif

#ifndef APP_MODDET_ASK_MIN_FREQ_PM
#define APP_MODDET_ASK_MIN_FREQ_PM           80U
#endif

#ifndef APP_MODDET_ASK_STRONG_ENV_PM
#define APP_MODDET_ASK_STRONG_ENV_PM         850U
#endif

#ifndef APP_MODDET_ASK_STRONG_EDGE_PM
#define APP_MODDET_ASK_STRONG_EDGE_PM        35U
#endif

#ifndef APP_MODDET_ENV_LEVEL_BINS
#define APP_MODDET_ENV_LEVEL_BINS            8U
#endif

#ifndef APP_MODDET_FSK_SIGN_MIN_PERCENT
#define APP_MODDET_FSK_SIGN_MIN_PERCENT      30U
#endif

#ifndef APP_MODDET_FSK_MIN_HIST_PEAKS
#define APP_MODDET_FSK_MIN_HIST_PEAKS        2U
#endif

#ifndef APP_MODDET_DPHI_ZERO_PM_THRESHOLD
#define APP_MODDET_DPHI_ZERO_PM_THRESHOLD    8U
#endif

#ifndef APP_MODDET_DPHI_STRONG_PM_THRESHOLD
#define APP_MODDET_DPHI_STRONG_PM_THRESHOLD  40U
#endif

#ifndef APP_MODDET_HIST_PEAK_MIN_PERCENT
#define APP_MODDET_HIST_PEAK_MIN_PERCENT     10U
#endif

#ifndef APP_MODDET_PSK_JUMP_PM_THRESHOLD
#define APP_MODDET_PSK_JUMP_PM_THRESHOLD     10U
#endif

#ifndef APP_MODDET_PSK_MIN_POS_PERCENT
#define APP_MODDET_PSK_MIN_POS_PERCENT       80U
#endif

#ifndef APP_MODDET_PSK_MAX_NEG_PERCENT
#define APP_MODDET_PSK_MAX_NEG_PERCENT       20U
#endif

#ifndef APP_MODDET_PSK_MAX_ENV_PM
#define APP_MODDET_PSK_MAX_ENV_PM            200U
#endif

#ifndef APP_MODDET_TRACE_DECIMATION_BLOCKS
#define APP_MODDET_TRACE_DECIMATION_BLOCKS   64U
#endif

typedef enum
{
  APP_MODDET_MODE_UNKNOWN = 0,
  APP_MODDET_MODE_NO_CARRIER,
  APP_MODDET_MODE_CW,
  APP_MODDET_MODE_AM,
  APP_MODDET_MODE_ASK,
  APP_MODDET_MODE_FM,
  APP_MODDET_MODE_FSK,
  APP_MODDET_MODE_PSK
} app_mod_detect_mode_t;

typedef struct
{
  uint32_t sample_rate_hz;      /* IQ 输入采样率，用于换算调制速率和频偏。 */
  uint16_t min_block_samples;   /* 小于该点数的 block 不参与调制识别。 */
  uint16_t reserved;            /* 预留字段，保持配置结构体后续兼容。 */
} app_mod_detect_config_t;

typedef struct
{
  app_mod_detect_mode_t mode;         /* 当前 block 的即时调制类型判定。 */
  uint32_t block_count;               /* 已处理的 IQ block 数。 */
  uint32_t ac_power;                  /* 去直流后的平均交流功率。 */
  uint32_t env_variation_pm;          /* 包络相对平均功率的变化量，单位 permille。 */
  uint32_t env_edge_pm;               /* 包络跳变密度，单位 permille。 */
  uint32_t freq_activity;             /* 相邻 IQ 向量相位活动强度，单位 permille。 */
  int32_t freq_bias;                  /* cross 均值，表示残余频偏方向和偏置。 */
  uint32_t fsk_balance_pm;            /* 正/负频率活动覆盖比例，单位 permille。 */
  uint32_t psk_jump_pm;               /* dot < 0 的事件密度，用于识别 PSK 相位翻转。 */
  uint32_t modulation_rate_hz;        /* 估计调制频率或码速率。 */
  uint32_t am_depth_pm;               /* AM/ASK 调幅深度估计，单位 permille。 */
  uint32_t fm_deviation_hz;           /* FM 频偏估计。 */
  uint32_t fsk_shift_hz;              /* FSK 频移估计。 */
  app_mod_detect_mode_t stable_mode;  /* 投票平滑后的调制类型，用于 UI 显示。 */
  uint16_t stable_confidence_percent; /* stable_mode 的投票置信度。 */
  uint16_t env_level_count;           /* 包络量化后占用的电平数量。 */
  uint16_t dphi_hist_peak_count;      /* 粗略相位差直方图中的峰数量。 */
  uint16_t positive_freq_percent;     /* cross > 0 的样本比例。 */
  uint16_t negative_freq_percent;     /* cross < 0 的样本比例。 */
  uint8_t carrier_present;            /* ac_power 达到最小门限后置 1。 */
  uint8_t reserved[3];                /* 预留字段，保持状态结构体对齐和后续兼容。 */
  int32_t residual_freq_hz;           /* 根据平均 dphi 估计的残余载波频偏。 */
  uint32_t envelope_peak_hz;          /* 预留：包络谱主峰频率。 */
  uint32_t phase_peak_hz;             /* 预留：相位差谱主峰频率。 */
  uint16_t envelope_harmonic_percent; /* 预留：包络谱谐波能量比例。 */
  uint16_t phase_harmonic_percent;    /* 预留：相位差谱谐波能量比例。 */
  uint16_t phase_state_count;         /* 预留：相位状态簇数量。 */
  uint16_t freq_state_count;          /* 预留：频率状态簇数量。 */

} app_mod_detect_status_t;

void app_mod_detect_init(const app_mod_detect_config_t *config);
void app_mod_detect_process_iq_block(const uint16_t *i_buf, const uint16_t *q_buf, uint32_t sample_cnt);
void app_mod_detect_get_status(app_mod_detect_status_t *status_out);
const char *app_mod_detect_mode_name(app_mod_detect_mode_t mode);

#ifdef __cplusplus
}
#endif

#endif /* APP_MOD_DETECT_H */