#include "app_adc_log.h"
#include "cmsis_os2.h"
#include "FreeRTOS.h"
#include "task.h"
#include "AppDebugConfig.h"
#include "RtosTypes.h"
#include <stdio.h>

#define APP_ADC_LOG_PERIOD_MS        1000U
#define APP_ADC_IQ_PREPROC_LOG_MS    1000U

#ifndef ADC_IQ_PREPROC_LOG_ENABLE
#define ADC_IQ_PREPROC_LOG_ENABLE ADC_ALGO_LOG_ENABLE
#endif

void app_adc_log_health_1s(const app_adc_log_health_snapshot_t *snapshot)
{
    static uint32_t last_log_tick = 0U;
    uint32_t now_tick;
    UBaseType_t adc_stack_words;
    UBaseType_t printf_stack_words;
    char log_buf[180];
    int n;

    if ((ADC_HEALTH_LOG_ENABLE == 0U) || (snapshot == NULL))
    {
        return;
    }

    now_tick = osKernelGetTickCount();
    if ((last_log_tick != 0U) &&
        ((uint32_t)(now_tick - last_log_tick) < APP_ADC_LOG_PERIOD_MS))
    {
        return;
    }
    last_log_tick = now_tick;

    if (g_uart_mode != UART_MODE_LOG)
    {
        return;
    }

    adc_stack_words = uxTaskGetStackHighWaterMark(NULL);
    printf_stack_words = (PrintfTaskHandle != NULL) ? uxTaskGetStackHighWaterMark(PrintfTaskHandle) : 0U;

    n = snprintf(log_buf,
                 sizeof(log_buf),
                 "adc_health: isr(h=%lu,f=%lu) task(h=%lu,f=%lu) pend=0x%02X ov=%lu stk_adc=%luW stk_printf=%luW\r\n",
                 (unsigned long)snapshot->isr_half,
                 (unsigned long)snapshot->isr_full,
                 (unsigned long)snapshot->task_half,
                 (unsigned long)snapshot->task_full,
                 (unsigned int)snapshot->pending_mask,
                 (unsigned long)snapshot->overrun,
                 (unsigned long)adc_stack_words,
                 (unsigned long)printf_stack_words);
    if (n > 0)
    {
        print_queue_send_log(log_buf);
    }
}

void app_adc_log_algo_1s(const app_signal_detect_status_t *sig)
{
    static uint32_t last_log_tick = 0U;
    uint32_t now_tick;
    char line[125];
    int n;

    if ((ADC_ALGO_LOG_ENABLE == 0U) || (sig == NULL))
    {
        return;
    }

    now_tick = osKernelGetTickCount();
    if ((last_log_tick != 0U) &&
        ((uint32_t)(now_tick - last_log_tick) < APP_ADC_LOG_PERIOD_MS))
    {
        return;
    }
    last_log_tick = now_tick;

    if (g_uart_mode != UART_MODE_LOG)
    {
        return;
    }

    n = snprintf(line,
                 sizeof(line),
                 "sig,s=%u,sc=%u,lk=%u,cp=%u,lo=%lu,est=%lu,k=%u/%u,v=%lu,p=%lu,n=%lu\r\n",
                 (unsigned)sig->stage,
                 (unsigned)sig->scanning,
                 (unsigned)sig->locked,
                 (unsigned)sig->carrier_present,
                 (unsigned long)sig->current_lo_hz,
                 (unsigned long)sig->estimated_carrier_hz,
                 (unsigned)(sig->step_index + 1U),
                 (unsigned)sig->step_count,
                 (unsigned long)sig->current_vpp_raw,
                 (unsigned long)sig->peak_vpp_raw,
                 (unsigned long)sig->valley_vpp_raw);
    if ((n > 0) && ((size_t)n < sizeof(line)))
    {
        print_queue_send_log(line);
    }
}

void app_adc_log_iq_preproc_1s(uint8_t tracking_active,
                               const app_iq_preproc_result_t *result,
                               const app_adc_log_iq_verify_snapshot_t *verify)
{
    static uint32_t last_log_tick = 0U;
    uint32_t now_tick;
    char line[128];
    int n;

    if ((ADC_IQ_PREPROC_LOG_ENABLE == 0U) || (result == NULL))
    {
        return;
    }

    now_tick = osKernelGetTickCount();
    if ((last_log_tick != 0U) &&
        ((uint32_t)(now_tick - last_log_tick) < APP_ADC_IQ_PREPROC_LOG_MS))
    {
        return;
    }
    last_log_tick = now_tick;

    if ((g_uart_mode != UART_MODE_LOG) || (tracking_active == 0U))
    {
        return;
    }

    n = snprintf(line,
                 sizeof(line),
                 "iq_pre,mi=%ld,mq=%ld,mag=%lu,fo_mhz=%ld,ph_urad=%ld,blk=%lu\r\n",
                 (long)result->mean_i,
                 (long)result->mean_q,
                 (unsigned long)result->mean_mag,
                 (long)result->residual_freq_millihz,
                 (long)(result->phase_acc_rad * 1000000.0f),
                 (unsigned long)result->block_count);
    if ((n > 0) && ((size_t)n < sizeof(line)))
    {
        print_queue_send_log(line);
    }

    if ((verify != NULL) && (verify->valid != 0U))
    {
        n = snprintf(line,
                     sizeof(line),
                     "iq_rot,rd=%ld,cd=%ld,ip=%ld,rh=%lu,rt=%lu,ch=%lu,ct=%lu,ov=%lu,rb=%lu\r\n",
                     (long)verify->raw_dphi_urad,
                     (long)verify->rot_dphi_urad,
                     (long)verify->improve_pm,
                     (unsigned long)verify->raw_head_mag,
                     (unsigned long)verify->raw_tail_mag,
                     (unsigned long)verify->rot_head_mag,
                     (unsigned long)verify->rot_tail_mag,
                     (unsigned long)verify->overrun_snapshot,
                     (unsigned long)verify->rotate_block_cnt_snapshot);
        if ((n > 0) && ((size_t)n < sizeof(line)))
        {
            print_queue_send_log(line);
        }
    }
}

uint8_t app_adc_log_range_1s(const app_adc_log_range_snapshot_t *snapshot)
{
    static uint32_t last_log_tick = 0U;
    uint32_t now_tick;
    uint32_t i_vpp;
    uint32_t q_vpp;
    char line[200];
    int n;

    if ((ADC_RANGE_LOG_ENABLE == 0U) || (snapshot == NULL))
    {
        return 0U;
    }

    now_tick = osKernelGetTickCount();
    if ((last_log_tick != 0U) &&
        ((uint32_t)(now_tick - last_log_tick) < APP_ADC_LOG_PERIOD_MS))
    {
        return 0U;
    }
    last_log_tick = now_tick;

    if ((g_uart_mode != UART_MODE_LOG) || (snapshot->sample_cnt == 0U))
    {
        return 0U;
    }

    i_vpp = (snapshot->i_max > snapshot->i_min) ? ((uint32_t)snapshot->i_max - (uint32_t)snapshot->i_min) : 0U;
    q_vpp = (snapshot->q_max > snapshot->q_min) ? ((uint32_t)snapshot->q_max - (uint32_t)snapshot->q_min) : 0U;

    n = snprintf(line,
                 sizeof(line),
                 "adc_range,imin=%u,imax=%u,qmin=%u,qmax=%u,ivpp=%lu,qvpp=%lu,iclo=%lu,ichi=%lu,qclo=%lu,qchi=%lu,inlo=%lu,inhi=%lu,qnlo=%lu,qnhi=%lu,n=%lu\r\n",
                 (unsigned)snapshot->i_min,
                 (unsigned)snapshot->i_max,
                 (unsigned)snapshot->q_min,
                 (unsigned)snapshot->q_max,
                 (unsigned long)i_vpp,
                 (unsigned long)q_vpp,
                 (unsigned long)snapshot->i_clip_lo,
                 (unsigned long)snapshot->i_clip_hi,
                 (unsigned long)snapshot->q_clip_lo,
                 (unsigned long)snapshot->q_clip_hi,
                 (unsigned long)snapshot->i_near_lo,
                 (unsigned long)snapshot->i_near_hi,
                 (unsigned long)snapshot->q_near_lo,
                 (unsigned long)snapshot->q_near_hi,
                 (unsigned long)snapshot->sample_cnt);
    if ((n > 0) && ((size_t)n < sizeof(line)))
    {
        print_queue_send_log(line);
        return 1U;
    }

    return 0U;
}
