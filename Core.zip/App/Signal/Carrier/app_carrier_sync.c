#include "app_carrier_sync.h"

#include <string.h>

#include "cmsis_os2.h"
#include "dac.h"

/* VRFE 实测中心电压：约 1.55V 时 OCXO 与信号源匹配。 */
#ifndef APP_CARRIER_SYNC_CENTER_MV
#define APP_CARRIER_SYNC_CENTER_MV 1550
#endif

/* 第一版只允许在中心点附近小范围慢速调整，避免把 OCXO 控制端拉到危险区域。 */
#ifndef APP_CARRIER_SYNC_MIN_MV
#define APP_CARRIER_SYNC_MIN_MV 1400
#endif

#ifndef APP_CARRIER_SYNC_MAX_MV
#define APP_CARRIER_SYNC_MAX_MV 1700
#endif

/* 闭环更新周期，单位 ms；当前按 1s 慢速积分。 */
#ifndef APP_CARRIER_SYNC_UPDATE_PERIOD_MS
#define APP_CARRIER_SYNC_UPDATE_PERIOD_MS 1000U
#endif

/* 残余频偏死区，单位 mHz；死区内不调整 VRFE，降低抖动。 */
#ifndef APP_CARRIER_SYNC_DEADBAND_MHZ
#define APP_CARRIER_SYNC_DEADBAND_MHZ 50
#endif

/* 每次闭环更新的电压步进，单位 mV。 */
#ifndef APP_CARRIER_SYNC_STEP_MV
#define APP_CARRIER_SYNC_STEP_MV 1
#endif

/*
 * 控制极性：
 *   +1：残余频偏为正时提高 VRFE 电压
 *   -1：残余频偏为正时降低 VRFE 电压
 * 若实测闭环方向相反，只改这个宏，不改扫频和 ADC 任务结构。
 */
#ifndef APP_CARRIER_SYNC_CONTROL_POLARITY
#define APP_CARRIER_SYNC_CONTROL_POLARITY 1
#endif

#define APP_CARRIER_SYNC_DAC_MAX_CODE 4095U
#define APP_CARRIER_SYNC_DAC_REF_MV   3300U

typedef struct
{
    app_carrier_sync_status_t status;          /* 对外可读状态快照。 */
    uint32_t last_update_tick;                 /* 上一次闭环调节的 RTOS tick。 */
} app_carrier_sync_ctx_t;

static app_carrier_sync_ctx_t g_carrier_sync;

/* 将目标电压限制在 VRFE 允许调整范围内。 */
static int32_t app_carrier_sync_clamp_mv(int32_t mv)
{
    if (mv < APP_CARRIER_SYNC_MIN_MV)
    {
        return APP_CARRIER_SYNC_MIN_MV;
    }

    if (mv > APP_CARRIER_SYNC_MAX_MV)
    {
        return APP_CARRIER_SYNC_MAX_MV;
    }

    return mv;
}

/* 将 mV 电压转换成 12-bit DAC code，按 3.3V 参考电压计算。 */
static uint16_t app_carrier_sync_mv_to_dac_code(int32_t mv)
{
    int32_t safe_mv = app_carrier_sync_clamp_mv(mv);
    uint32_t code = (((uint32_t)safe_mv * APP_CARRIER_SYNC_DAC_MAX_CODE) +
                     (APP_CARRIER_SYNC_DAC_REF_MV / 2U)) /
                    APP_CARRIER_SYNC_DAC_REF_MV;

    if (code > APP_CARRIER_SYNC_DAC_MAX_CODE)
    {
        code = APP_CARRIER_SYNC_DAC_MAX_CODE;
    }

    return (uint16_t)code;
}

/* 写入 DAC1_OUT1；第一次写入时同步启动 DAC 通道。 */
static void app_carrier_sync_apply_mv(int32_t mv)
{
    uint16_t code = app_carrier_sync_mv_to_dac_code(mv);

    g_carrier_sync.status.control_mv = app_carrier_sync_clamp_mv(mv);
    g_carrier_sync.status.dac_code = code;

#if (APP_CARRIER_SYNC_ENABLE != 0U)
    if (HAL_DAC_SetValue(&hdac1, DAC_CHANNEL_1, DAC_ALIGN_12B_R, code) != HAL_OK)
    {
        g_carrier_sync.status.last_error = -1;
        return;
    }

    if (g_carrier_sync.status.dac_started == 0U)
    {
        if (HAL_DAC_Start(&hdac1, DAC_CHANNEL_1) != HAL_OK)
        {
            g_carrier_sync.status.last_error = -2;
            return;
        }
        g_carrier_sync.status.dac_started = 1U;
    }
#endif

    g_carrier_sync.status.last_error = 0;
}

/* 初始化闭环状态，并让 VRFE 先回到 1.55V 中心点。 */
void app_carrier_sync_init(void)
{
    memset(&g_carrier_sync, 0, sizeof(g_carrier_sync));
    g_carrier_sync.status.enabled = (APP_CARRIER_SYNC_ENABLE != 0U) ? 1U : 0U;
    app_carrier_sync_apply_mv(APP_CARRIER_SYNC_CENTER_MV);
}

/* 退出锁定态或重新扫频时回到中心点，避免沿用上一轮积分偏置。 */
void app_carrier_sync_reset_to_center(void)
{
    g_carrier_sync.status.locked_gate = 0U;
    g_carrier_sync.status.residual_freq_millihz = 0;
    g_carrier_sync.last_update_tick = osKernelGetTickCount();
    app_carrier_sync_apply_mv(APP_CARRIER_SYNC_CENTER_MV);
}

/* 锁定后每秒最多调整 1 mV，避免 VRFE 因瞬态残余频偏被快速拉偏。 */
void app_carrier_sync_update(uint8_t locked_gate, const app_iq_preproc_result_t *iq_result)
{
    uint32_t now_tick;
    int32_t residual;
    int32_t abs_residual;
    int32_t direction;
    int32_t next_mv;

    if ((APP_CARRIER_SYNC_ENABLE == 0U) || (g_carrier_sync.status.enabled == 0U))
    {
        return;
    }

    if ((locked_gate == 0U) || (iq_result == NULL))
    {
        if (g_carrier_sync.status.locked_gate != 0U)
        {
            app_carrier_sync_reset_to_center();
        }
        g_carrier_sync.status.locked_gate = 0U;
        g_carrier_sync.status.hold_count++;
        return;
    }

    now_tick = osKernelGetTickCount();
    if ((uint32_t)(now_tick - g_carrier_sync.last_update_tick) < APP_CARRIER_SYNC_UPDATE_PERIOD_MS)
    {
        return;
    }
    g_carrier_sync.last_update_tick = now_tick;

    residual = iq_result->residual_freq_millihz;
    abs_residual = (residual >= 0) ? residual : -residual;
    g_carrier_sync.status.locked_gate = 1U;
    g_carrier_sync.status.residual_freq_millihz = residual;

    if (abs_residual <= APP_CARRIER_SYNC_DEADBAND_MHZ)
    {
        g_carrier_sync.status.hold_count++;
        return;
    }

    direction = (residual > 0) ? 1 : -1;
    next_mv = g_carrier_sync.status.control_mv +
              (direction * APP_CARRIER_SYNC_CONTROL_POLARITY * APP_CARRIER_SYNC_STEP_MV);
    next_mv = app_carrier_sync_clamp_mv(next_mv);

    app_carrier_sync_apply_mv(next_mv);
    g_carrier_sync.status.update_count++;
}

/* 返回当前闭环状态快照。 */
void app_carrier_sync_get_status(app_carrier_sync_status_t *status_out)
{
    if (status_out == NULL)
    {
        return;
    }

    *status_out = g_carrier_sync.status;
}
